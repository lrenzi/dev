﻿'use strict';
app.controller('homeController', ['$scope', function ($scope) {
   
}]);